# Database design

```mermaid
erDiagram
    USERS ||--o{ ATTENDANCE : submits
    USERS {
      int id PK
      string roll UK
      string name
      string course
      string semester
      string email UK
      string password_hash
      string role
    }
    SUBJECTS ||--o{ ATTENDANCE : records
    SUBJECTS {
      int id PK
      string name UK
      string teacher
    }
    ATTENDANCE {
      int id PK
      string roll FK
      string subject FK
      date day
      string status
      datetime marked_time
      boolean verified
      string verified_by
    }
```

Note: In the prototype, attendance references student roll and subject name; a production schema should use numeric foreign keys and enforce role permissions on the server.
